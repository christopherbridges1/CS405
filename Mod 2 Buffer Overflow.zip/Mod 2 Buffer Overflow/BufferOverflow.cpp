// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Chris Bridges CS 405 13 SEP 2025

#include <iomanip>
#include <iostream>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    const std::string account_number = "CharlieBrown42";
    char user_input[20];
    std::cout << "Enter a value: ";

    //Gets user_input and size of user_input to prevent overflow
    std::cin.get(user_input, sizeof(user_input));
    bool too_long = false;

    // if next character is not newline or EOF, the input was too long
    int next = std::cin.peek();
    if (next != '\n' && next != EOF) {
        too_long = true;

        // Removes the rest of the line
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    else if (next == '\n') {
        // Consumes newline so future reads are clean 
        std::cin.get();
    }

    if (too_long) {
        std::cout << "[NOTICE] You entered more than 19 characters; only the first 19 were used." << std::endl;
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu