// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits

//Chris Bridges CS 405 Secure Coding September 7 2025

template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps, bool& ok)
{
    T result = start;
    ok = true; // assumes success, changes to false if detects a boundary issue

    if (steps == 0 || increment == static_cast<T>(0)) {
        return result;
    }

    if constexpr (std::numeric_limits<T>::is_integer) {
        // Integer addition with pre-check
        for (unsigned long int i = 0; i < steps; ++i) {
            if (increment > 0) {
                // Would this exceed max?
                if (result > std::numeric_limits<T>::max() - increment) {
                    ok = false;               // signals overflow
                    return result;            // returns the last safe value
                }
            }
            else { // increment < 0
                // Would this go below min?
                if (result < std::numeric_limits<T>::min() - increment) {
                    ok = false;               // signals underflow
                    return result;
                }
            }
            result = static_cast<T>(result + increment);
        }
    }
    else {
        // Floating-point: checks finite & bounds
        for (unsigned long int i = 0; i < steps; ++i) {
            T next = static_cast<T>(result + increment);

            // NaN check
            if (next != next) {
                ok = false;
                return result;
            }
            // Range check
            if (next > std::numeric_limits<T>::max() || next < std::numeric_limits<T>::lowest()) {
                ok = false;
                return result;
            }
            result = next;
        }
    }

    return result;
}
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, bool& ok)
{
    T result = start;
    ok = true; // assumes success

    if (steps == 0 || decrement == static_cast<T>(0)) {
        return result;
    }

    if constexpr (std::numeric_limits<T>::is_integer) {
        // Integer subtraction with pre-check
        for (unsigned long int i = 0; i < steps; ++i) {
            if (decrement > 0) {
                // result - decrement < min => underflow
                if (result < static_cast<T>(std::numeric_limits<T>::min() + decrement)) {
                    ok = false;
                    return result;
                }
            }
            else { // decrement < 0  
                // result - decrement == result + |decrement| > max => overflow
                if (result > static_cast<T>(std::numeric_limits<T>::max() + decrement)) {
                    ok = false;
                    return result;
                }
            }
            result = static_cast<T>(result - decrement);
        }
    }
    else {
        // Floating-point checks finite & bounds 
        for (unsigned long int i = 0; i < steps; ++i) {
            T next = static_cast<T>(result - decrement);

            if (next != next) { // NaN
                ok = false;
                return result;
            }
            if (next > std::numeric_limits<T>::max() || next < std::numeric_limits<T>::lowest()) {
                ok = false;
                return result;
            }
            result = next;
        }
    }

    return result;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // TODO: The add_numbers template function will overflow in the second method call
    //        You need to change the add_numbers method to:
    //        1. Detect when an overflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no overflow happened or
    //        4. Return something to tell test_overflow the addition failed
    //        NOTE: The add_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_overflow method to:
    //        1. Detect when an add_numbers failed
    //        2. Inform the user the overflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_overflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    bool ok = true;

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    T result = add_numbers<T>(start, increment, steps, ok);
    if (ok) {
        std::cout << "overflow=false, result=" << +result << std::endl;
    }
    else {
        std::cout << "overflow=true, result=NA" << std::endl;
    }

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1, ok);
    if (ok) {
        std::cout << "overflow=false, result=" << +result << std::endl;
    }
    else {
        std::cout << "overflow=true, result=NA" << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    // TODO: The subtract_numbers template function will underflow in the second method call
    //        You need to change the subtract_numbers method to:
    //        1. Detect when an underflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no underflow happened or
    //        4. Return something to tell test_underflow the subtraction failed
    //        NOTE: The subtract_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_underflow method to:
    //        1. Detect when an subtract_numbers failed
    //        2. Inform the user the underflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_underflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem. 
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    bool ok = true;

    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    T result = subtract_numbers<T>(start, decrement, steps, ok);
    if (ok) {
        std::cout << "underflow=false, result=" << +result << std::endl;
    }
    else {
        std::cout << "underflow=true, result=NA" << std::endl;
    }

    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1, ok);
    if (ok) {
        std::cout << "underflow=false, result=" << +result << std::endl;
    }
    else {
        std::cout << "underflow=true, result=NA" << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu