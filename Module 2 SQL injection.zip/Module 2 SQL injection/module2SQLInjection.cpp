// SQLInjection.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <algorithm>
#include <iostream>
#include <locale>
#include <tuple>
#include <vector>

#include "sqlite3.h"

// DO NOT CHANGE
typedef std::tuple<std::string, std::string, std::string> user_record;
const std::string str_where = " where ";

// DO NOT CHANGE
static int callback(void* possible_vector, int argc, char** argv, char** azColName)
{
    if (possible_vector == NULL)
    { // no vector passed in, so just display the results
        for (int i = 0; i < argc; i++)
        {
            std::cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << std::endl;
        }
        std::cout << std::endl;
    }
    else
    {
        std::vector< user_record >* rows =
            static_cast<std::vector< user_record > *>(possible_vector);

        rows->push_back(std::make_tuple(argv[0], argv[1], argv[2]));
    }
    return 0;
}

// DO NOT CHANGE
bool initialize_database(sqlite3* db)
{
    char* error_message = NULL;
    std::string sql = "CREATE TABLE USERS(" \
        "ID INT PRIMARY KEY     NOT NULL," \
        "NAME           TEXT    NOT NULL," \
        "PASSWORD       TEXT    NOT NULL);";

    int result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
    if (result != SQLITE_OK)
    {
        std::cout << "Failed to create USERS table. ERROR = " << error_message << std::endl;
        sqlite3_free(error_message);
        return false;
    }
    std::cout << "USERS table created." << std::endl;

    // insert some dummy data
    sql = "INSERT INTO USERS (ID, NAME, PASSWORD)" \
        "VALUES (1, 'Fred', 'Flinstone');" \
        "INSERT INTO USERS (ID, NAME, PASSWORD)" \
        "VALUES (2, 'Barney', 'Rubble');" \
        "INSERT INTO USERS (ID, NAME, PASSWORD)" \
        "VALUES (3, 'Wilma', 'Flinstone');" \
        "INSERT INTO USERS (ID, NAME, PASSWORD)" \
        "VALUES (4, 'Betty', 'Rubble');";

    result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
    if (result != SQLITE_OK)
    {
        std::cout << "Data failed to insert to USERS table. ERROR = " << error_message << std::endl;
        sqlite3_free(error_message);
        return false;
    }

    return true;
}

bool run_query(sqlite3* db, const std::string& sql, std::vector< user_record >& records){
   
    auto is_space = [](char c) {
        return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\v';
        };
    auto skip_spaces = [&](const std::string& s, size_t i) {
        while (i < s.size() && is_space(s[i])) ++i;
        return i;
        };
    auto is_digit = [](char c) { return c >= '0' && c <= '9'; };
    auto is_alpha = [](char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'); };
    auto is_word_char = [&](char c) { return is_alpha(c) || is_digit(c) || c == '_'; };

    // trim helpers
    auto rtrim = [&](std::string& s) {
        while (!s.empty() && is_space(s.back())) s.pop_back();
        };
    auto ltrim = [&](std::string& s) {
        size_t i = 0;
        while (i < s.size() && is_space(s[i])) ++i;
        if (i) s.erase(0, i);
        };
    auto trim = [&](std::string& s) { rtrim(s); ltrim(s); };

    // lowercase copy
    std::string sqlLower = sql;
    for (char& ch : sqlLower) {
        if (ch >= 'A' && ch <= 'Z') ch = static_cast<char>(ch - 'A' + 'a');
    }

    // Find last the last " where " 
    size_t whereStart = std::string::npos;
    {
        const std::string needle = " where ";
        size_t from = 0, hit;
        while ((hit = sqlLower.find(needle, from)) != std::string::npos) {
            whereStart = hit;
            from = hit + needle.size();
        }
    }

    // Parses a number starting at i -> returns the end index
    auto parse_number = [&](const std::string& s, size_t i, std::string& out) -> size_t {
        size_t j = i;
        while (j < s.size() && is_digit(s[j])) ++j;
        out.assign(s.begin() + i, s.begin() + j);
        return j;
        };

    // Parse single-quoted string starting at i
    auto parse_sq_string = [&](const std::string& s, size_t i, size_t& endPos, std::string& inner) -> bool {
        if (i >= s.size() || s[i] != '\'') return false;
        size_t j = i + 1;
        while (j < s.size() && s[j] != '\'') ++j;
        if (j >= s.size()) return false;
        inner.assign(s.begin() + i + 1, s.begin() + j);
        endPos = j + 1;
        return true;
        };

    // Look for:  OR <literal> = <same literal>  
    bool suspected = false;
    size_t cutPos = std::string::npos;
    std::string matchedText;

    {
        size_t scanFrom = (whereStart == std::string::npos) ? 0 : whereStart;
        size_t i = scanFrom;

        while (true) {
            // find "or" as a word
            size_t k = sqlLower.find("or", i);
            if (k == std::string::npos) break;

            bool leftWordBoundary = (k == 0) || !is_word_char(sqlLower[k - 1]);
            bool rightWordBoundary = (k + 2 >= sqlLower.size()) || !is_word_char(sqlLower[k + 2]);
            if (!(leftWordBoundary && rightWordBoundary)) {
                i = k + 2;
                continue;
            }

            // After "OR", expect a literal, then =, then the same literal again
            size_t p = skip_spaces(sql, k + 2);

            std::string A, B;
            bool firstIsString = false;
            size_t end1 = p;

            // first literal
            if (p < sql.size() && sql[p] == '\'') {
                size_t endQ = 0; std::string inner;
                if (!parse_sq_string(sql, p, endQ, inner)) { i = k + 2; continue; }
                A = inner; firstIsString = true; end1 = endQ;
            }
            else if (p < sql.size() && is_digit(sql[p])) {
                end1 = parse_number(sql, p, A);
                firstIsString = false;
            }
            else {
                i = k + 2; continue;
            }

            // '='
            size_t p2 = skip_spaces(sql, end1);
            if (p2 >= sql.size() || sql[p2] != '=') { i = k + 2; continue; }

            // second literal 
            size_t p3 = skip_spaces(sql, p2 + 1);
            size_t end2 = p3;

            if (firstIsString) {
                size_t endQ2 = 0; std::string inner2;
                if (!parse_sq_string(sql, p3, endQ2, inner2)) { i = k + 2; continue; }
                B = inner2; end2 = endQ2;
            }
            else {
                if (p3 >= sql.size() || !is_digit(sql[p3])) { i = k + 2; continue; }
                end2 = parse_number(sql, p3, B);
            }

            // If the two are the same
            if (A == B) {
                suspected = true;
                cutPos = k; // cut starting at the O in OR
                size_t tail = skip_spaces(sql, end2);
                if (tail < sql.size() && sql[tail] == ';') ++tail;
                matchedText.assign(sql.begin() + k, sql.begin() + tail);
                break;
            }

            i = k + 2; // continues searching for another "OR"
        }
    }

    // Clear prior results
    records.clear();

    // If injection detected run the filtered SQL
    std::string toExecute = sql;
    if (suspected && cutPos != std::string::npos) {
        toExecute = sql.substr(0, cutPos);
        trim(toExecute);
        if (toExecute.empty() || toExecute.back() != ';') {
            toExecute.push_back(';');
        }

        std::cout << "[BLOCKED] Removed suspicious clause: " << "\"" << matchedText << "\"\n";
        std::cout << "[ACTION] Running filtered SQL: " << toExecute << std::endl;
    }

    char* error_message = nullptr;
    if (sqlite3_exec(db, toExecute.c_str(), callback, &records, &error_message) != SQLITE_OK)
    {
        std::cout << "Data failed to be queried from USERS table. ERROR = " << error_message << std::endl;
        sqlite3_free(error_message);
        return false;
    }

    return true;
}



// DO NOT CHANGE
bool run_query_injection(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
    std::string injectedSQL(sql);
    std::string localCopy(sql);

    // we work on the local copy because of the const
    std::transform(localCopy.begin(), localCopy.end(), localCopy.begin(), ::tolower);
    if (localCopy.find_last_of(str_where) >= 0)
    { // this sql has a where clause
        if (localCopy.back() == ';')
        { // smart SQL developer terminated with a semicolon - we can fix that!
            injectedSQL.pop_back();
        }

        switch (rand() % 4)
        {
        case 1:
            injectedSQL.append(" or 2=2;");
            break;
        case 2:
            injectedSQL.append(" or 'hi'='hi';");
            break;
        case 3:
            injectedSQL.append(" or 'hack'='hack';");
            break;
        case 0:
        default:
            injectedSQL.append(" or 1=1;");
            break;
        }
    }

    return run_query(db, injectedSQL, records);
}


// DO NOT CHANGE
void dump_results(const std::string& sql, const std::vector< user_record >& records)
{
    std::cout << std::endl << "SQL: " << sql << " ==> " << records.size() << " records found." << std::endl;

    for (auto record : records)
    {
        std::cout << "User: " << std::get<1>(record) << " [UID=" << std::get<0>(record) << " PWD=" << std::get<2>(record) << "]" << std::endl;
    }
}

// DO NOT CHANGE
void run_queries(sqlite3* db)
{
    char* error_message = NULL;

    std::vector< user_record > records;

    // query all
    std::string sql = "SELECT * from USERS";
    if (!run_query(db, sql, records)) return;
    dump_results(sql, records);

    //  query 1
    sql = "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred'";
    if (!run_query(db, sql, records)) return;
    dump_results(sql, records);

    //  run query 1 with injection 5 times
    for (auto i = 0; i < 5; ++i)
    {
        if (!run_query_injection(db, sql, records)) continue;
        dump_results(sql, records);
    }

}

// You can change main by adding stuff to it, but all of the existing code must remain, and be in the
// in the order called, and with none of this existing code placed into conditional statements
int main()
{
    // initialize random seed:
    srand(time(nullptr));

    int return_code = 0;
    std::cout << "SQL Injection Example" << std::endl;

    // the database handle
    sqlite3* db = NULL;
    char* error_message = NULL;

    // open the database connection
    int result = sqlite3_open(":memory:", &db);

    if (result != SQLITE_OK)
    {
        std::cout << "Failed to connect to the database and terminating. ERROR=" << sqlite3_errmsg(db) << std::endl;
        return -1;
    }

    std::cout << "Connected to the database." << std::endl;

    // initialize our database
    if (!initialize_database(db))
    {
        std::cout << "Database Initialization Failed. Terminating." << std::endl;
        return_code = -1;
    }
    else
    {
        run_queries(db);
    }

    // close the connection if opened
    if (db != NULL)
    {
        sqlite3_close(db);
    }

    return return_code;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
