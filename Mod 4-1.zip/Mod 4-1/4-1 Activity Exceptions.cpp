// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Chris Bridges CS 405

#include <iostream>
// Libraries added for exception handling
#include <stdexcept>
#include <string>

// Custom exception class from standard exception
class CustomException : public std::exception {
public:
    explicit CustomException(const std::string& msg) : message(msg) {}
    const char* what() const noexcept override {
        return message.c_str();
    }
private:
    std::string message;
};

// Function that simulates more application logic and throws a standard exception
bool do_even_more_custom_application_logic(){
    // Throws a standard exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;

	// Simulate an error condition
    throw std::runtime_error("Standard exception: problem in even more logic");
	return true;
}

// Function that simulates application logic and throws a custom exception
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

	// Call another function that may throw an exception
    try {
        do_even_more_custom_application_logic();
        std::cout << "Even More Logic succeeded." << std::endl;
    }
	// Handle the standard exception
    catch (const std::exception& e) {
        std::cerr << "Caught std::exception: " << e.what() << std::endl;
    }

	// Continue with custom logic
    std::cout << "Leaving Custom Application Logic." << std::endl;
    // Throws a custom exception
    throw CustomException("Custom exception: problem in custom logic");
}

// Function that performs division and may throw a domain_error exception
float divide(float num, float den)
{
	// Check for division by zero
    if (den == 0) {
        throw std::domain_error("Divided by zero");
    }
    return num / den;
}

// Function that calls divide and handles exceptions
void do_division() noexcept
{
    float a = 10.0f;
    float b = 0.0f;

	// Call divide and handle potential exceptions
    try {
        float result = divide(a, b);
        std::cout << "Result = " << result << std::endl;
    }
	// Handle domain_error exception
    catch (const std::domain_error& e) {
        std::cerr << "Caught domain_error in do_division: " << e.what() << std::endl;
    }
}

// Main function demonstrating exception handling
int main()
{
	// Top-level try-catch block to handle any uncaught exceptions
    try {
        std::cout << "Starting Exceptions Tests" << std::endl;

        do_division();
        do_custom_application_logic();
    }
	// Handle custom exceptions
    catch (const CustomException& e) {
        std::cerr << "Caught CustomException in main: " << e.what() << std::endl;
    }
	// Handle standard exceptions
    catch (const std::exception& e) {
        std::cerr << "Caught std::CustomException in main: " << e.what() << std::endl;
    }
	// Handle any other unknown exceptions
    catch (...) {
        std::cerr << "Caught unknown exception in main." << std::endl;
    }

	// Indicates end of program
    std::cout << "End of program." << std::endl;
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu